const fetch = require('node-fetch');

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function extractJsonObject(text) {
  if (!text || typeof text !== 'string') return null;

  // Try parsing directly first
  try {
    return JSON.parse(text);
  } catch (_) {
    // continue
  }

  // Fallback: extract the first {...} block.
  const firstBrace = text.indexOf('{');
  const lastBrace = text.lastIndexOf('}');
  if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) return null;

  const candidate = text.slice(firstBrace, lastBrace + 1);
  try {
    return JSON.parse(candidate);
  } catch (_) {
    return null;
  }
}

async function analyzeWithGemini({ claim, evidenceArticles }) {
  try {
    const API_KEY = process.env.API_KEY;
    if (!API_KEY) {
      throw new Error('Missing API_KEY in environment variables');
    }

    const model = process.env.GEMINI_MODEL || 'gemini-flash-latest';
    const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

    const evidence = Array.isArray(evidenceArticles) ? evidenceArticles : [];
    const evidencePreview = evidence.slice(0, 8).map((a) => ({
      title: a.title || '',
      source: a.source || '',
      description: a.description || '',
      url: a.url || '',
      content: a.content ? String(a.content).slice(0, 1500) : '',
    }));

    const promptText = `You are a fact-checking AI.

Task:
Given a claim and the related evidence from news sources, decide whether the claim is TRUE or FALSE.

Rules:
1. Use ONLY the provided evidence. If evidence is weak/irrelevant, treat the claim as FALSE (low credibility).
2. Your output MUST match the JSON schema exactly.
3. Do not include markdown or extra text.

Claim (verbatim):
${JSON.stringify(claim)}

Related evidence (JSON array):
${JSON.stringify(evidencePreview)}
`;

    const responseSchema = {
      type: 'object',
      properties: {
        verdict: { type: 'boolean', description: 'true if claim is supported by evidence, else false' },
        credibility_score: {
          type: 'number',
          description: '0-100 score',
        },
        status: { type: 'string', enum: ['Real', 'Fake'], description: 'Human readable label' },
        confidence_level: { type: 'string', enum: ['Low', 'Medium', 'High'] },
        reason: { type: 'string', description: 'Short explanation referencing evidence' },
      },
      required: ['verdict', 'credibility_score', 'status', 'confidence_level', 'reason'],
    };

    const payload = {
      contents: [
        {
          parts: [
            {
              text: promptText,
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0,
        top_p: 1,
        max_output_tokens: 256,
        response_mime_type: 'application/json',
        response_schema: responseSchema,
      },
    };

    const timeoutMs = Number(process.env.GEMINI_TIMEOUT_MS || 20000);
    const fetchWithTimeout = async (url, options) => {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await fetch(url, { ...options, signal: controller.signal });
      } finally {
        clearTimeout(t);
      }
    };

    const url = `${API_URL}?key=${API_KEY}`;

    let lastErr = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await fetchWithTimeout(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (!response.ok) {
          const errorData = await response.text();
          throw new Error(`Gemini API HTTP ${response.status}: ${errorData}`);
        }

        const data = await response.json();
        const parts = data?.candidates?.[0]?.content?.parts || [];
        const aiResponseText = parts
          .map((p) => (p && typeof p.text === 'string' ? p.text : ''))
          .filter(Boolean)
          .join('\n')
          .trim();

        if (!aiResponseText) throw new Error('Invalid response structure from Gemini API');

        const parsed = extractJsonObject(aiResponseText);
        if (!parsed) throw new Error('AI response parsing failed (no valid JSON object)');

        const verdict = Boolean(parsed.verdict);
        const credibility_score = Number(parsed.credibility_score);
        const status = parsed.status === 'Real' ? 'Real' : 'Fake';
        const confidence_level = parsed.confidence_level || 'Low';
        const reason = String(parsed.reason || '').trim() || 'No reason returned by AI';

        return {
          verdict,
          credibility_score: Math.max(0, Math.min(100, credibility_score)),
          status,
          confidence_level,
          reason,
        };
      } catch (err) {
        lastErr = err;
        const msg = String(err.message || err);
        const shouldRetry =
          attempt < 2 && (msg.includes('429') || msg.includes('HTTP 5') || msg.includes('aborted'));
        if (!shouldRetry) break;
        await sleep(600 * (attempt + 1));
      }
    }

    throw lastErr || new Error('Gemini request failed');
  } catch (error) {
    console.error('Gemini Service Error:', error.message);
    return {
      verdict: false,
      credibility_score: 50,
      status: 'Fake',
      confidence_level: 'Low',
      reason: 'AI service unavailable',
    };
  }
}

module.exports = { analyzeWithGemini };
