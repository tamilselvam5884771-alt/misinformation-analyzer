# MIA News Analyzer Backend

Express backend that:
1. Fetches related articles from **GNews**
2. Uses **Gemini** to produce a structured TRUE/FALSE verdict with evidence
3. Returns a clean boolean verdict for credibility

## Run locally

1. Install deps:
   `npm install`
2. Create `.env` from `.env.example` and fill the keys:
   - `API_KEY` (Gemini)
   - `GNEWS_API_KEY` (GNews)
3. Start server:
   - `npm start`

## API

### Health

`GET /`

### Analyze a claim

`POST /analyze`

Body (JSON):
```json
{
  "text": "Your news claim / statement here"
}
```

Response (JSON):
```json
{
  "credibility": 0,
  "status": "Real" | "Fake",
  "is_credible": true | false,
  "confidence_level": "Low" | "Medium" | "High",
  "reason": "Short explanation",
  "signals": {
    "clickbait_detected": false,
    "keywords_matched": 0
  },
  "related_news": [
    { "title": "...", "source": "...", "url": "..." }
  ]
}
```

## Notes

- The Gemini call is configured for structured JSON output (so results are not “messy”).
- If Gemini or GNews fails, the endpoint degrades gracefully (it will still return a valid JSON response).

