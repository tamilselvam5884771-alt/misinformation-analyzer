const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { analyzeWithGemini } = require('./geminiService');
const { fetchRelatedNews } = require('./newsService');
const { extractKeywords, calculateSimilarity, detectFakeSignals } = require('./similarity');

const app = express();
const PORT = process.env.PORT || 5000;

// Enable JSON parsing and CORS
app.use(cors());
app.use(express.json());

// Basic route to verify server is running
app.get('/', (req, res) => {
  res.send('Backend Server is running.');
});

// POST API endpoint `/analyze`
app.post('/analyze', async (req, res) => {
  try {
    const { text } = req.body;

    // Validate input
    if (!text) {
      return res.status(400).json({ error: 'No text provided' });
    }

    // 1. Fetch Related News (real-time evidence)
    const relatedNews = await fetchRelatedNews(text);

    // 2. Similarity Logic & Score Calculation (used as bonus/penalty)
    let similarityScore = 0;
    let maxKeywordsMatched = 0;
    const inputKeywords = extractKeywords(text);
    
    if (relatedNews.length > 0) {
      const similarityResult = calculateSimilarity(inputKeywords, relatedNews);
      similarityScore = similarityResult.score || 0;
      maxKeywordsMatched = similarityResult.maxMatched || 0;
    }

    // 3. Fake Signal Detection (used as penalty)
    const fakeSignalPenalty = detectFakeSignals(text);
    const clickbaitDetected = fakeSignalPenalty > 0;

    // 4. Get Gemini Verdict (structured output)
    let aiResult;
    try {
      aiResult = await analyzeWithGemini({ claim: text, evidenceArticles: relatedNews });
    } catch (aiError) {
      console.error('Gemini AI failed, using fallback:', aiError);
      aiResult = {
        verdict: false,
        credibility_score: 50,
        status: 'Fake',
        confidence_level: 'Low',
        reason: 'AI service unavailable',
      };
    }

    // 5. Calculate Final Credibility Score
    let finalCredibility = Number(aiResult.credibility_score);
    if (Number.isNaN(finalCredibility)) finalCredibility = 50;

    // Keep Gemini's verdict as the final TRUE/FALSE answer.
    const isCredible = Boolean(aiResult.verdict);

    // Ensure it's between 0 and 100 and a rounded integer
    finalCredibility = Math.max(0, Math.min(100, Math.round(finalCredibility)));

    // Confidence Level
    let confidenceLevel = aiResult.confidence_level || "Low";
    if (!["Low", "Medium", "High"].includes(confidenceLevel)) {
      if (finalCredibility > 75) confidenceLevel = "High";
      else if (finalCredibility >= 40) confidenceLevel = "Medium";
    }

    // Adjust status based on new score
    const finalStatus = isCredible ? "Real" : "Fake";

    // Build the combined reason
    const finalReason = `${aiResult.reason} Found ${relatedNews.length} related articles. Keyword match score: ${Math.round(similarityScore)}/100.` + (fakeSignalPenalty > 0 ? ` Note: Detected fake news buzzwords (-${fakeSignalPenalty} penalty).` : "");

    // 6. Final output formatted properly
    return res.json({
      credibility: finalCredibility,
      status: finalStatus,
      is_credible: isCredible,
      confidence_level: confidenceLevel,
      reason: finalReason.trim(),
      signals: {
        clickbait_detected: clickbaitDetected,
        keywords_matched: maxKeywordsMatched
      },
      related_news: relatedNews.map(news => ({
        title: news.title,
        source: news.source,
        url: news.url
      }))
    });

  } catch (error) {
    console.error('Error in /analyze endpoint:', error);
    return res.status(500).json({ error: "Something went wrong" });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
